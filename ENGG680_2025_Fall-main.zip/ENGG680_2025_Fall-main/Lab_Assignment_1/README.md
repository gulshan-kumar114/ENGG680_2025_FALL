Perry Zhang           30274239

Nabin Devkota      30295378

Gulshan Kumar      30296437

Taien Chen             30298923



##### This assignment is about python data types, pandas data frame and Linear LSE.

